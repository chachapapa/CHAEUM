-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: i9a810.p.ssafy.io    Database: coco_chacha
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `nickname` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `is_registered` bit(1) NOT NULL,
  `profile_url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_6dotkott2kjsp8vw4d0m25fb7` (`email`),
  UNIQUE KEY `UK_2ty1xmrrgtn89xt7kyxx6ta7h` (`nickname`)
) ENGINE=InnoDB AUTO_INCREMENT=2971251693 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (2942065323,'darkard37@gmail.com','정민영',NULL,_binary '','https://cocochacha.s3.ap-northeast-2.amazonaws.com/8c3c2600-03a6-41e8-9be6-b0cc0c0141f9-da0f66a937177652f08d16005891d2438f324a0b9c48f77dbce3a43bd11ce785-removebg-preview.png'),(2943445223,'kjn4785@naver.com','김의년',NULL,_binary '','http://k.kakaocdn.net/dn/dpk9l1/btqmGhA2lKL/Oz0wDuJn1YV2DIn92f6DVK/img_640x640.jpg'),(2945536967,'kgw6147@kakao.com','김선우',NULL,_binary '','http://k.kakaocdn.net/dn/ta3BN/btrGCDKsyHn/VB3w9AcpQ3DV8drsC3Cajk/img_640x640.jpg'),(2945712458,'khappy517@naver.com','권소희',NULL,_binary '','http://k.kakaocdn.net/dn/COsE6/btsakc4YGam/2W1opKX5FUXuekzK2kWRzk/img_640x640.jpg'),(2946244921,'bell1129@kakao.com','채현종',NULL,_binary '','http://k.kakaocdn.net/dn/bxUjuo/btsiQjtE7tk/1vkaDEwGCIVo7It0fweFM0/img_640x640.jpg'),(2946252441,'djyun7@daum.net','윤다정',NULL,_binary '','http://k.kakaocdn.net/dn/boR4iw/btsjiRq5iV2/rCIC4owLCK07x9hRVZJCvk/img_640x640.jpg'),(2946269856,'pkgun727@hanmail.net','박동건',NULL,_binary '','http://k.kakaocdn.net/dn/beT0rl/btr7pT06d2V/AFXjOIXC7hTtmHiLNYVw5K/img_640x640.jpg'),(2948554272,'jjw4199@naver.com','차차아버님',NULL,_binary '','http://k.kakaocdn.net/dn/be7IHc/btso7RTwFPK/xeVQfKV2o7GNvPkbvqOkiK/img_640x640.jpg'),(2950823951,'kjy6135@naver.com','강준영',NULL,_binary '','http://k.kakaocdn.net/dn/dySp4Q/btsl4lBIVBc/VMMMdUKBaw1Hm3Dq2QIkEK/img_640x640.jpg'),(2952869517,'yung5487@naver.com','지용현',NULL,_binary '','http://k.kakaocdn.net/dn/dpk9l1/btqmGhA2lKL/Oz0wDuJn1YV2DIn92f6DVK/img_640x640.jpg'),(2970891719,'sooyeon7027@naver.com','오수연',NULL,_binary '\0','http://k.kakaocdn.net/dn/dpk9l1/btqmGhA2lKL/Oz0wDuJn1YV2DIn92f6DVK/img_640x640.jpg'),(2971251692,'kimjw3928@daum.net','김지원',NULL,_binary '\0','http://k.kakaocdn.net/dn/Q09o6/btsmUJaAaRU/CucaPePaE45EwfKPtkvo20/img_640x640.jpg');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-08-17 15:03:58
